#!/bin/bash
cd /var/www/html
sudo rm -rf *

#!/bin/bash

sudo systemctl restart httpd
